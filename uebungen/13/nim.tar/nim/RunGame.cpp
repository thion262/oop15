#include <cstdlib>
#include <unistd.h>
#include <iostream>

#define NIM_GAME_DEFINE

#include "NimGame.hpp"
#include "HumanNimPlayer.hpp"
#include "OptimalNimPlayer.hpp"
#include "NimParameters.hpp"

using namespace std;

int main() {
   // seed pseudo random generator
   srand(getpid() ^ time(0));

   cout << "*** Game of Nim ***" << endl;

   // read parameters of the game
   unsigned int number_of_heaps;
   cout << "Number of heaps: ";
   if (!(cin >> number_of_heaps) || number_of_heaps == 0) {
      cout << "Bye!" << endl; return 1;
   }

   // setup game
   typedef NimGame<MAX_HEAP_SIZE, MOVES> Game;
   Game game(number_of_heaps);
   unsigned int minsize = game.moves[0];
   unsigned int maxsize = MAX_HEAP_SIZE;
   unsigned int range = maxsize - minsize + 1;
   for (unsigned int i = 0; i < number_of_heaps; ++i) {
      game.set_heap_size(i, rand() % range + minsize);
   }

   cout << "Possible moves:";
   for (int move: game.moves) {
      cout << " " << move;
   }
   cout << endl;

   HumanNimPlayer<Game> human_player;
   OptimalNimPlayer<Game> optimal_player;

   while (!game.finished()) {
      cout << "Heaps:";
      for (unsigned int i = 0; i < number_of_heaps; ++i) {
	 cout << " " << game.get_heap_size(i);
      }
      cout << endl;
      NimMove move;
      switch (game.get_next_player()) {
	 case Game::PLAYER1: move = human_player.get_move(game); break;
	 case Game::PLAYER2: move = optimal_player.get_move(game); break;
      }
      if (move.has_resigned()) {
	 switch (game.get_next_player()) {
	    case Game::PLAYER1: cout << "You resign." << endl; break;
	    case Game::PLAYER2: cout << "The computer resigns." << endl; break;
	 }
      } else {
	 cout << move.get_count() << " items are taken from heap "
	 << move.get_heap() << endl;
      }
      game.execute_move(move);
   }
   switch (game.winner()) {
      case Game::PLAYER1:
	 cout << "Congratulations, you have won!" << endl; break;
      case Game::PLAYER2:
	 cout << "Too bad, you lost!" << endl; break;
   }
}
