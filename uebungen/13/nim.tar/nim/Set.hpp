#ifndef SET_H
#define SET_H

template<unsigned int candidate, unsigned int ... members>
struct IsMemberInSet;

template<unsigned int candidate>
struct IsMemberInSet<candidate> {
   public:
      static constexpr bool is_member = false;
};

template<unsigned int candidate, unsigned int first_member,
   unsigned int ... other_members>
struct IsMemberInSet<candidate, first_member, other_members...> {
   public:
      static constexpr bool is_member = (candidate == first_member) ||
		      IsMemberInSet<candidate, other_members...>::is_member;
};

#endif
