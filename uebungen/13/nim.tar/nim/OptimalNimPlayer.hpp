#ifndef OPTIMAL_NIM_PLAYER
#define OPTIMAL_NIM_PLAYER

#include <iostream>
#include <string>
#include "NimMove.hpp"

template<typename Game>
struct OptimalNimPlayer {
   NimMove get_move(const Game& game) const {
      unsigned int number_of_heaps = game.get_number_of_heaps();
      if (game.nim_value() == 0) {
	 // bad luck
	 for (unsigned int i = 0; i < number_of_heaps; ++i) {
	    if (game.get_heap_size(i) > game.moves[0]) {
	       return NimMove(i, game.moves[0]);
	    }
	 }
      } else {
	 // find a winning move
	 for (unsigned int i = 0; i < number_of_heaps; ++i) {
	    unsigned int max = game.get_heap_size(i);
	    for (unsigned int count: game.moves) {
	       if (count > max) continue;
	       Game test = game;
	       NimMove move(i, count);
	       test.execute_move(move);
	       if (test.nim_value() == 0) {
		  return move;
	       }
	    }
	 }
      }
      // oops, our algorithm failed, we give up...
      return NimMove();
   }
};

#endif
