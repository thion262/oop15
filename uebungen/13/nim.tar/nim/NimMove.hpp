#ifndef NIM_MOVE_H
#define NIM_MOVE_H

#include <cassert>

class NimMove {
   public:
      NimMove() : resigned(true) {
      }
      NimMove(unsigned int _heap, unsigned int _count) :
	 heap(_heap), count(_count), resigned(false) {
      }
      bool has_resigned() const {
	 return resigned;
      }
      unsigned int get_heap() const {
	 assert(!resigned);
	 return heap;
      }
      unsigned int get_count() const {
	 assert(!resigned);
	 return count;
      }

   private:
      unsigned int heap;
      unsigned int count;
      bool resigned;
};

#endif
