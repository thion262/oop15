#ifndef TABLE_H
#define TABLE_H

template<unsigned int I, unsigned int N, template<unsigned int> class F,
   unsigned int ... values>
struct TableConstructor;

template<unsigned int N, template<unsigned int> class F,
       unsigned int ... values>
struct TableConstructor<0, N, F, values...> {
   static constexpr unsigned int len = N;
   typedef unsigned int type[len];
   static constexpr type val = {F<0>::value, values...};
};

template<unsigned int I, unsigned int N, template<unsigned int> class F,
   unsigned int ... values>
struct TableConstructor :
   public TableConstructor<I-1, N, F, F<I>::value, values...> {
};

template<unsigned int N, template<unsigned int> class F>
struct Table : public TableConstructor<N-1, N, F> {
};

template<unsigned int N, template<unsigned int> class F,
       unsigned int ... values>
constexpr typename TableConstructor<0, N, F, values...>::type
   TableConstructor<0, N, F, values...>::val;

#endif
