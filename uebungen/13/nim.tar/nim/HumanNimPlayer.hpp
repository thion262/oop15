#ifndef HUMAN_NIM_PLAYER
#define HUMAN_NIM_PLAYER

#include <iostream>
#include <string>
#include "NimMove.hpp"

template<typename Game>
struct HumanNimPlayer {
   NimMove get_move(const Game& game) const {
      using namespace std;
      NimMove move;
      do {
	 unsigned int heap_index; unsigned int count;
	 cout << "Your move: ";
	 if (!(cin >> heap_index >> count)) {
	    return NimMove();
	 }
	 move = NimMove(heap_index, count);
      } while (!game.valid_move(move));
      return move;
   }
};

#endif
