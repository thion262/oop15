#ifndef NIM_PARAMETERS_H
#define NIM_PARAMETERS_H

/* default parameters */

#ifndef MOVES
#define MOVES 1, 2, 3 /* smallest move first! */
#endif

#ifndef MAX_HEAP_SIZE
#define MAX_HEAP_SIZE 20
#endif

#endif
