#include <cassert>
#include <vector>
#include "NimGame.hpp"

NimGame::NimGame(unsigned int number_of_heaps_, unsigned int maxtake_) :
      number_of_heaps(number_of_heaps_), maxtake(maxtake_),
      /* make heap_size a vector of number_of_heaps elements */
      heap_size(number_of_heaps_),
      next_player(PLAYER1) {
}

unsigned int NimGame::get_number_of_heaps() const {
   return number_of_heaps;
}

void NimGame::set_heap_size(unsigned int index, unsigned int size) {
   assert(index < number_of_heaps);
   heap_size[index] = size;
}

unsigned int NimGame::get_heap_size(unsigned int index) const {
   /* FIXME */
}

bool NimGame::finished() const {
   /* FIXME */
}

NimGame::Player NimGame::winner() const {
   /* FIXME */
}

NimGame::Player NimGame::get_next_player() const {
   /* FIXME */
}

bool NimGame::valid_move(NimMove move) const {
   /* FIXME */
}

void NimGame::execute_move(NimMove move) {
   /* FIXME */
}

unsigned int NimGame::nim_value() const {
   /* FIXME */
}
