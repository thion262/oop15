#ifndef STACK_H
#define STACK_H

#include <cassert>
#include "types.hpp"

namespace LambdaCalc {

   class Stack {
      public:
	 /* next: stack of closure, value: put on top of the stack */
	 Stack(StackPtr next_, ValuePtr value_) :
	    value(value_), next(next_), len(next_? next_->len+1: 1) {
	 }
	 /* closure first, then the value */
	 ValuePtr operator[](unsigned int index) const {
	    assert(index < len);
	    if (index == len-1) return value;
	    return (*next)[index];
	 }
      private:
	 ValuePtr value;
	 StackPtr next;
	 unsigned int len; // stack length including next and value
   };

} // namespace LambdaCalc

#endif
