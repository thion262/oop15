#include <iostream>
#include "token.hpp"

namespace LambdaCalc {

   const char* const Token::symname[DEFINE+1] = {
      "ERROR", "END", "IDENT", "LAMBDA", "LPAREN",
      "RPAREN", "INTEGER", "IF", "DEFINE"
   };

   std::ostream& operator<<(std::ostream& out, const Token& token) {
      out << Token::symname[token.symbol];
      if (token.symbol == Token::IDENT && token.identifier.length() > 0) {
	 out << " (" << token.identifier << ")";
      } else if (token.symbol == Token::INTEGER) {
	 out << " (" << token.integer << ")";
      }
      return out;
   }

} // namespace LambdaCalc
