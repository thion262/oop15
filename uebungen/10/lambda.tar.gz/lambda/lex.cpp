#include <cctype>
#include "lex.hpp"

namespace LambdaCalc {

bool isspecial(char ch) {
   switch (ch) {
      case '+':
      case '-':
      case '*':
      case '/':
      case '=':
      case '<':
      case '>':
      case '!':
	 return true;

      default:
	 return false;
   }
}

Lex::Lex(std::istream& in_, std::ostream& out_,
	 const std::string& prompt1_, const std::string& prompt2_) :
      in(in_), out(out_), prompt1(prompt1_), prompt2(prompt2_),
      eof(false), error(false), ch(0), start(true), finished(true) {
   next();
}

// accessors
bool Lex::valid() const {
   return !eof && !error;
}

// mutators
void Lex::markFinished() {
   finished = true;
}

Token Lex::getToken() {
   while (!error && !eof && isspace(ch)) {
      next();
   }
   if (error) {
      return Token(Token::ERROR);
   }
   if (eof) {
      return Token(Token::END);
   }
   finished = false;

   // simple symbols
   switch (ch) {
      case '(':
	 next();
	 return Token(Token::LPAREN);

      case ')':
	 next();
	 return Token(Token::RPAREN);

   }

   if (isalpha(ch) || isspecial(ch)) {
      // identifier or keyword
      std::string ident; ident += ch;
      next();
      while (!eof && !error && (isalnum(ch) || isspecial(ch))) {
	 ident += ch; next();
      }
      if (ident == "lambda") {
	 return Token(Token::LAMBDA);
      } else if (ident == "define") {
	 return Token(Token::DEFINE);
      } else if (ident == "if") {
	 return Token(Token::IF);
      } else {
	 return Token(Token::IDENT, ident);
      }
   }

   if (isdigit(ch)) {
      // constant value
      int val = ch - '0';
      next();
      while (!eof && !error && isdigit(ch)) {
	 val = val * 10 + ch - '0'; next();
      }
      return Token(Token::INTEGER, val);
   }

   error = true;
   return Token(Token::ERROR);
}

Lex::operator bool() const {
   return valid();
}
Lex& Lex::operator>>(Token& token) {
   token = getToken(); return *this;
}

void Lex::next() {
   if (eof || error) return;
   if (start) {
      if (finished) {
	 out << prompt1;
      } else {
	 out << prompt2;
      }
      out.flush();
      start = false;
   }
   ch = in.get();
   if (in) {
      if (ch == '\n') {
	 start = true;
      }
   } else {
      ch = 0;
      if (in.eof()) {
	 eof = true;
      } else {
	 error = true;
      }
   }
}

} // namespace LambdaCalc
