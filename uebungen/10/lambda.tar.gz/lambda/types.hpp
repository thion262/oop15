#ifndef TYPES_H
#define TYPES_H

#include <functional>
#include <memory>

namespace LambdaCalc {

   class Value;
   typedef std::shared_ptr<Value> ValuePtr;

   class Stack;
   typedef std::shared_ptr<Stack> StackPtr;

   typedef std::function<ValuePtr(StackPtr)> Function;
   typedef std::shared_ptr<Function> FunctionPtr;

} // namespace LambdaCalc

#endif
