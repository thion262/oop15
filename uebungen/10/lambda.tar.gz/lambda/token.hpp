#ifndef TOKEN_H
#define TOKEN_H

#include <string>
#include "types.hpp"

namespace LambdaCalc {

   struct Token {
      typedef enum {ERROR, END, IDENT, LAMBDA, LPAREN,
	 RPAREN, INTEGER, IF, DEFINE} Symbol;
      static const char* const symname[DEFINE+1];
      Symbol symbol;
      std::string identifier;
      int integer;

      Token() : symbol(ERROR) {};
      Token(Symbol symbol_) : symbol(symbol_) {};
      Token(Symbol symbol_, const std::string& identifier_) :
	 symbol(symbol_), identifier(identifier_), integer(0) {
      }
      Token(Symbol symbol_, int integer_) :
	 symbol(symbol_), integer(integer_) {
      }

      bool valid() {
	 return symbol > END;
      }
   };

   std::ostream& operator<<(std::ostream& out, const Token& token);

} // namespace LambdaCalc

#endif
