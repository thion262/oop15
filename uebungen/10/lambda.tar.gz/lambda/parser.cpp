#include <cassert>
#include <sstream>
#include "token.hpp"
#include "value.hpp"
#include "parser.hpp"
#include "runtime.hpp"
#include "stack.hpp"

namespace LambdaCalc {

Parser::Exception::Exception(const Token& token, const std::string& msg_) {
   std::ostringstream osmsg;
   osmsg << "At " << token << ": " << msg_;
   msg = osmsg.str();
}

Parser::Exception::~Exception() throw() {};

const char* Parser::Exception::what() const throw() {
   return msg.c_str();
}

Parser::Parser(Lex& lex_, SymbolTable& symtab_) :
      lex(lex_), symtab(symtab_), tokenConsumed(true) {
}

FunctionPtr Parser::getFunction() throw(Exception) {
   getToken();
   if (!lex.valid()) {
      return FunctionPtr((Function*) 0);
   }
   bindings.clear();
   FunctionPtr f = parseExpression();
   lex.markFinished();
   return f;
}

void Parser::nextToken() {
   if (tokenConsumed) {
      token = lex.getToken();
   } else {
      tokenConsumed = true;
   }
}

Token Parser::getToken() {
   if (tokenConsumed) {
      token = lex.getToken();
      tokenConsumed = false;
   }
   return token;
}

unsigned int Parser::findBinding(const std::string& varname) {
   unsigned int count = 0;
   for (const Binding& binding: bindings) {
      ++count;
      if (binding.varname == varname) return count;
   }
   return 0;
}

FunctionPtr Parser::parseExpression() throw(Exception) {
   // expr --> identifier
   if (getToken().symbol == Token::IDENT) {
      std::string varname = getToken().identifier;
      nextToken();
      unsigned int index = findBinding(varname);
      if (index) {
	 // FIXME: return lambda expression returning local variable from sp 
	 return FunctionPtr(nullptr);
      }
      // FIXME: return lambda expression looking up definition in symtab
      return FunctionPtr(nullptr);
   }

   // expr --> integer
   if (getToken().symbol == Token::INTEGER) {
      int integer = getToken().integer;
      nextToken();
      // FIXME: return lambda expression returning constant integer value
      return FunctionPtr(nullptr);
   }

   // all other variants start with '('
   if (getToken().symbol != Token::LPAREN) {
      throw Exception(getToken(), "identifier, integer or '(' expected");
   }
   nextToken();

   // expr --> '(' lambda identifier expr ')'
   if (getToken().symbol == Token::LAMBDA) {
      nextToken();
      if (getToken().symbol != Token::IDENT) {
	 throw Exception(getToken(), "variable expected");
      }

      // open local scope with the variable and parse function body
      bindings.push_back(getToken().identifier);
      nextToken();
      FunctionPtr value = parseExpression();
      bindings.pop_back();

      if (getToken().symbol != Token::RPAREN) {
	 throw Exception(getToken(), "')' expected");
      }
      nextToken();
      // FIXME: return lambda expression that returns this function
      return FunctionPtr(nullptr);
   }

   // expr --> '(' define identifier expr ')'
   if (getToken().symbol == Token::DEFINE) {
      nextToken();
      if (getToken().symbol != Token::IDENT) {
	 throw Exception(getToken(), "identifier expected");
      }
      std::string name = getToken().identifier;
      nextToken();
      FunctionPtr expr = parseExpression();
      if (getToken().symbol != Token::RPAREN) {
	 throw Exception(getToken(), "')' expected");
      }
      nextToken();
      // FIXME: return lambda expression that connects name
      // with value in symtab and which returns value
      return FunctionPtr(nullptr);
   }

   // expr --> '(' if expr expr expr')'
   if (getToken().symbol == Token::IF) {
      nextToken();
      FunctionPtr condition = parseExpression();
      FunctionPtr then_part = parseExpression();
      FunctionPtr else_part = parseExpression();
      if (getToken().symbol != Token::RPAREN) {
	 throw Exception(getToken(), "')' expected");
      }
      nextToken();
      // FIXME: return lambda expression that evaluates
      // condition and in dependence of that either evaluates
      // then_part or else_part
      return FunctionPtr(nullptr);
   }

   // expr --> '(' expr expr ')'
   FunctionPtr funexpr = parseExpression();
   FunctionPtr paramexpr = parseExpression();
   if (getToken().symbol != Token::RPAREN) {
      throw Exception(getToken(), "')' expected");
   }
   nextToken();
   // FIXME: return lambda expression that evaluates
   // funexpr and paramexpr and that invokes the function
   // with its parameter (but do not forget the closure)
   return FunctionPtr(nullptr);
}

} // namespace LambdaCalc
