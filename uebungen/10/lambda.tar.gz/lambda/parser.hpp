#ifndef PARSER_H
#define PARSER_H

#include <exception>
#include <list>
#include "lex.hpp"
#include "symbol-table.hpp"
#include "types.hpp"

namespace LambdaCalc {

   /*
      Parser for simple expressions:

      expr --> identifier
      expr --> integer
      expr --> '(' expr expr ')'
      expr --> '(' lambda identifier expr ')'
      expr --> '(' define identifier expr ')'
      expr --> '(' if expr expr expr')'
   */

   class Parser {
      public:
	 class Exception: public std::exception {
	    public:
	       Exception(const Token& token, const std::string& msg_);
	       virtual ~Exception() throw();
	       virtual const char* what() const throw();
	    private:
	       std::string msg;
	 };

	 Parser(Lex& lex_, SymbolTable& symtab_);

	 FunctionPtr getFunction() throw(Exception);

      private:
	 Lex& lex; // input channel
	 SymbolTable& symtab; // used for macros

	 Token token; // current token
	 bool tokenConsumed; // true, if we need to fetch the next token

	 struct Binding {
	    std::string varname;
	    Binding(const std::string& varname_) : varname(varname_) {};
	 };
	 std::list<Binding> bindings; // lexically scoped bindings

	 void nextToken();
	 Token getToken();
	 unsigned int findBinding(const std::string& varname);
	 FunctionPtr parseExpression() throw(Exception);
   };

} // namespace LambdaCalc

#endif
