#include "runtime.hpp"
#include "stack.hpp"
#include "value.hpp"
#include "binary.hpp"

namespace LambdaCalc {

ValuePtr make_binary(BinaryOp binop) {
   FunctionPtr binf = FunctionPtr(new Function([binop] (StackPtr sp)
	    -> ValuePtr {
      ValuePtr op1 = (*sp)[0];
      return ValuePtr(new Value(FunctionPtr(new Function([binop,op1]
	    (StackPtr sp) -> ValuePtr {
	 ValuePtr op2 = (*sp)[0];
	 if (op1->get_type() != Value::INTEGER ||
	       op2->get_type() != Value::INTEGER) {
	    throw RuntimeException("integer expected for binary function");
	 }
	 return ValuePtr(new Value(binop(op1->get_integer(),
	    op2->get_integer())));
      }))));
   }));
   return ValuePtr(new Value(binf));
}

} // namespace LambdaCalc
