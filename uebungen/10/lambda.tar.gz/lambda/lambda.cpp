#include "parser.hpp"
#include "lex.hpp"
#include "symbol-table.hpp"
#include "value.hpp"
#include "binary.hpp"
#include "runtime.hpp"
#include <iostream>

using namespace std;
using namespace LambdaCalc;

int main() {
   Lex lex(cin, cout, "> ", "| ");
   SymbolTable symtab;
   Parser parser(lex, symtab);

   /* Predefined functions */
   symtab.define("+", make_binary([](int a, int b){ return a + b; }));
   symtab.define("-", make_binary([](int a, int b){ return a - b; }));
   symtab.define("*", make_binary([](int a, int b){ return a * b; }));
   symtab.define("/", make_binary([](int a, int b){ return a / b; }));
   symtab.define("=", make_binary([](int a, int b){ return a == b; }));
   symtab.define("<", make_binary([](int a, int b){ return a < b; }));
   symtab.define("<=", make_binary([](int a, int b){ return a <= b; }));
   symtab.define(">", make_binary([](int a, int b){ return a > b; }));
   symtab.define(">=", make_binary([](int a, int b){ return a >= b; }));
   symtab.define("!=", make_binary([](int a, int b){ return a != b; }));

   /* Abort on syntax errors, i.e. no recovery takes place
      except by printing a final error message and exiting
      the program. */
   try {
      /* Run the outer loop as long as we receive syntactically
	 correct expressions. */
      FunctionPtr f;
      while (f = parser.getFunction()) {
	 ValuePtr value = (*f)(nullptr);
	 if (value->get_type() == Value::INTEGER) {
	    cout << value->get_integer() << endl;
	 }
      }
   } catch (Parser::Exception e) {
      cout << endl << e.what() << endl;
   } catch (RuntimeException e) {
      cout << endl << "runtime exception: " << e.what() << endl;
   }
}
