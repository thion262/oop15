#ifndef RUNTIME_H
#define RUNTIME_H

#include <exception>
#include <string>

namespace LambdaCalc {

   class RuntimeException: public std::exception {
      public:
	 RuntimeException(const std::string& msg_) : msg(msg_) {};
	 virtual ~RuntimeException() throw() {};
	 virtual const char* what() const throw() {
	    return msg.c_str();
	 }
      private:
	 const std::string msg;
   };

}

#endif
