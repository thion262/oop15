#ifndef VALUE_H
#define VALUE_H

#include <cassert>
#include <new>
#include "types.hpp"

namespace LambdaCalc {

   class Value {
      public:
	 typedef enum {FUNCTION, INTEGER} Type;
	 Value(int integer_) : type(INTEGER) {
	    new(&integer) int(integer_);
	 };
	 Value(FunctionPtr function_) : type(FUNCTION) {
	    new(&funvalue) FunctionValue(function_, nullptr);
	 };
	 Value(FunctionPtr function_, StackPtr sp_) : type(FUNCTION) {
	    new(&funvalue) FunctionValue(function_, sp_);
	 };
	 ~Value() {
	    switch (type) {
	       case FUNCTION: funvalue.~FunctionValue(); break;
	       default: /* nothing to be done */ break;
	    }
	 }
	 Type get_type() const {
	    return type;
	 }
	 int get_integer() const {
	    assert(type == INTEGER);
	    return integer;
	 }
	 FunctionPtr get_function() const {
	    assert(type == FUNCTION);
	    return funvalue.function;
	 }
	 StackPtr get_closure() const {
	    assert(type == FUNCTION);
	    return funvalue.sp;
	 }
      private:
	 Type type;
	 struct FunctionValue {
	    FunctionValue(FunctionPtr function_, StackPtr sp_) :
	       function(function_), sp(sp_) {
	    }
	    FunctionPtr function;
	    StackPtr sp;
	 };
	 union {
	    FunctionValue funvalue;
	    int integer;
	 };
   };

}

#endif
