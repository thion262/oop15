#ifndef BINARY_H
#define BINARY_H

#include <functional>
#include "types.hpp"

namespace LambdaCalc {

   typedef std::function<int(int, int)> BinaryOp;
   ValuePtr make_binary(BinaryOp binop);

} // namespace LambdaCalc

#endif
