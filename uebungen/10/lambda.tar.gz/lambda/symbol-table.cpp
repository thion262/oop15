#include "symbol-table.hpp"
#include "value.hpp"

namespace LambdaCalc {

void SymbolTable::define(const std::string& name, ValuePtr value) {
   table[name] = value;
}

ValuePtr SymbolTable::get(const std::string& name) const {
   Table::const_iterator it = table.find(name);
   if (it == table.end()) {
      return ValuePtr((Value*) 0);
   }
   return it->second;
}

} // namespace LambdaCalc
