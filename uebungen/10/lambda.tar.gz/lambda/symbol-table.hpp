#ifndef SYMBOL_TABLE_H
#define SYMBOL_TABLE_H

#include <map>
#include <string>
#include "types.hpp"

namespace LambdaCalc {

   /*
      Table of global variables.
   */
   class SymbolTable {
      public:
	 /* define or redefine a macro */
	 void define(const std::string& name, ValuePtr value);

	 /* retrieve the lambda expression associated with
	    the given name; null is returned if the name
	    has not been bound to an expression */
	 ValuePtr get(const std::string& name) const;

      private:
	 typedef std::map<std::string, ValuePtr> Table;
	 Table table;
   };

} // namespace LambdaCalc

#endif
