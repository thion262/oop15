#ifndef LEX_H
#define LEX_H

#include <iostream>
#include "token.hpp"

namespace LambdaCalc {

   class Lex {
      public:
	 Lex(std::istream& in_, std::ostream& out_,
	    const std::string& prompt1_, const std::string& prompt2_);

	 // accessors
	 bool valid() const;
	    /* check if this lex object continues to read from
	       its input. Once this returns false, the return
	       value remains false fur all further invocations */

	 // mutators
	 void markFinished();
	    /* tell the lexical analyser that a complete
	       expression has been read. This information is used
	       to print the correct prompt. */
	 Token getToken();
	    /* read and return the next token from the input.
	       Note however that no further read operations are
	       performed once an error or end of file has been
	       found. */

	 // istream-like behaviour
	 operator bool() const;
	 Lex& operator>>(Token& token);

      private:
	 std::istream& in; // input stream
	 std::ostream& out; // used for prompts
	 const std::string prompt1; // at the beginning of an expression
	 const std::string prompt2; // in the middle of an expression
	 bool eof; // eof detected? this flag is sticky!
	 bool error; // error detected? this is sticky as well
	 char ch; // current character read
	 bool start; // at the beginning of a line?
	 bool finished; // was one expression finished?

	 void next();
   };

} // namespace LambdaCalc

#endif
